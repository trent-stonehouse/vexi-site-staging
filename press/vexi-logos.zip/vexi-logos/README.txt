VEXI logo kit. Dark = for dark backgrounds; light = for light backgrounds.
Please do not recolor, stretch, outline or add effects to the mark.
The wordmark SVGs use live DM Sans text; outline them once before print.
